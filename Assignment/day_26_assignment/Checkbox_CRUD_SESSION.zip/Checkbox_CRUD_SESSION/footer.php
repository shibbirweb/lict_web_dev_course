 		</div>
 		<div class="footer_area">
 			<h2>&copy; Shibbir Ahmed</h2>
 		</div>
 	</div>
 </body>
 </html>