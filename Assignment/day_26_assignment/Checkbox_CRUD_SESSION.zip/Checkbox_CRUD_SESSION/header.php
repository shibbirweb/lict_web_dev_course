 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>Checkbox CRUD by SESSION</title>
 	<style type="text/css">
 		body{font-family: Verdana;}
 		.container{width: 100%; margin: 0 auto; background: #ddd;}
 		.header_area, .footer_area{background: #555; padding: 10px 0; text-align: center;}
 		.header_area h2, .footer_area h2{color: #fff;}
 		.section_area{min-height: 400px; padding: 10px;}
 	</style>
 </head>
 <body>
 	<div class="container">
 		<div class="header_area">
 			<h2>Checkbox CRUD using $_SESSION</h2>
 		</div>
 		<div class="section_area">